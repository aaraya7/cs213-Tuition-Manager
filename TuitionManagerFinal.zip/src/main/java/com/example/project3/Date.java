package com.example.project3;
import java.util.Calendar;
/**
 Takes a date and stores the day, month, and year as int values.
 @author Aaditya Rayadurgam
 */
public class Date implements Comparable<Date> {
    public static final int QUADRENNIAL = 4;
    public static final int CENTENNIAL = 100;
    public static final int QUATERCENTENNIAL = 400;
    public static final int LEAP_YEAR = 29;
    public static final int MAX_DAYS = 31;
    private int year;
    private int month;
    private int day;

    /**
     Constructor that uses the current date to create a Date object.
     */
    public Date(){
        Calendar current = Calendar.getInstance();
        year = current.get(Calendar.YEAR);
        month = current.get(Calendar.MONTH) + 1;
        day = current.get(Calendar.DAY_OF_MONTH);
    } //create an object with today’s date (see Calendar class)

    /**
     Constructor that uses a specific date to create a Date object.
     @param date is a date in the form "mm/dd/yyyy"
     */
    public Date(String date) {
        String[] inputs = date.split("/");
        year = Integer.parseInt(inputs[2]);
        month = Integer.parseInt(inputs[0]);
        day = Integer.parseInt(inputs[1]);
    }

    /**
     Checks if a date is valid based on whether the day exists in the month,
     the month exists in the year, and the year exists in the current time period.
     @return true if the date is valid and false if invalid
     */
    public boolean isValid() {
        if(year < 0 || year > Calendar.getInstance().get(Calendar.YEAR)){
            return false;
        }
        if(month < Calendar.JANUARY + 1 || month > Calendar.DECEMBER + 1){
            return false;
        }
        if(day <= 0){
            return false;
        }

        if(month == Calendar.FEBRUARY + 1){
            boolean leap = false;
            if(year % QUADRENNIAL == 0){
                if(year % CENTENNIAL != 0 || year % QUATERCENTENNIAL == 0){
                    leap = true;
                }
            }
            if(leap){
                if(day > LEAP_YEAR){
                    return false;
                }
            }else if(day > LEAP_YEAR - 1){
                return false;
            }
        }
        if(month == Calendar.APRIL + 1 || month == Calendar.JUNE + 1 ||
                month == Calendar.SEPTEMBER + 1 || month == Calendar.NOVEMBER + 1){
            if(day > MAX_DAYS-1){
                return false;
            }
        }else{
            if(day > MAX_DAYS){
                return false;
            }
        }
        return true;
    }

    /**
     Overrides the toString() method of the Object class.
     @return date as a string in the form "mm/dd/yyyy"
     */
    @Override
    public String toString(){
        return month + "/" + day + "/" + year;
    }

    /**
     Overrides the compareTo(T) method of the Comparable interface.
     @param date is a date in the form "mm/dd/yyyy"
     @return 1 if this date is newer than the parameter date, 0 if equal, and -1 if older
     */
    @Override
    public int compareTo(Date date){
        if(this.year > date.year){
            return 1;
        }else if(this.year < date.year){
            return -1;
        }else{
            if(this.month > date.month){
                return 1;
            }else if(this.month < date.month){
                return -1;
            }else{
                if(this.day > date.day){
                    return 1;
                }else if(this.day < date.day){
                    return -1;
                }
            }
        }
        return 0;
    }

    /**
     Overrides the equals(Object) method of the Object class.
     @param date is an object in the form "mm/dd/yyyy"
     @return true if this date is equal to the parameter date and false if not
     */
    @Override
    public boolean equals(Object date){
        if(!(date instanceof Date)){
            return false;
        }
        Date typed = (Date) date;
        return ((this.year == typed.year) && (this.month == typed.month) && (this.day == typed.day));
    }

    /**
     Finds the difference between the current date and another date in years.
     */
    public int age(){
        Date today = new Date();
        int age = today.year-this.year;
        if(today.month-this.month < 0){
            age-=1;
        }else if(today.month-this.month == 0){
            if(today.day-this.day < 0){
                age-=1;
            }
        }
        return age;
    }

    /**
     Testbed method to test the isValid() method of the Date class.
     @param args an array containing the command line argument used as a test input.
     */
    public static void main(String[] args){
        Date testDate = new Date(args[0]);
        System.out.print(testDate.isValid());
    }
}