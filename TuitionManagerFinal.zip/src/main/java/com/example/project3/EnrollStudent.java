package com.example.project3;
/**
 Takes a profile and a number of credits enrolled and stores them as an EnrolledStudent object.
 @author Aaditya Rayadurgam
 */
public class EnrollStudent {
    private Profile profile;
    private int creditsEnrolled;

    /**
     Constructor that uses name, date, and credit inputs to initialize the instance variables.
     ....
     @param first is a first name
     @param last is a last name
     @param dob is a date in the form "mm/dd/yyyy"
     @param creditsEnrolled is the number of credits the student is enrolled in
     ...
     */
    public EnrollStudent(String first, String last, String dob, String creditsEnrolled){
        profile = new Profile(first, last, dob);
        this.creditsEnrolled = Integer.parseInt(creditsEnrolled);
    }

    /**
     Getter that returns the profile of the EnrollStudent.
     ....
     @return profile is the profile instance variable.
     ...
     */
    public Profile getProfile() {
        return profile;
    }

    /**
     Getter that returns the number of credits an EnrollStudent is enrolled for.
     ....
     @return creditsEnrolled is the creditsEnrolled instance variable.
     ...
     */
    public int getCreditsEnrolled() {
        return creditsEnrolled;
    }

    /**
     Setter that changes the number of credits enrolled.
     ....
     @param creditsEnrolled is a number of credits to be enrolled for.
     ...
     */
    public void setCreditsEnrolled(int creditsEnrolled) {
        this.creditsEnrolled = creditsEnrolled;
    }

    /**
     Overrides the equals(Object) method of the Object class.
     ....
     @param enrollStudent is an EnrollStudent
     @return true if this EnrollStudent is equal to the parameter EnrollStudent and false if not
     ...
     */
    @Override
    public boolean equals(Object enrollStudent){
        if(!(enrollStudent instanceof EnrollStudent)){
            return false;
        }
        EnrollStudent typed = (EnrollStudent) enrollStudent;
        return ((this.profile.equals(typed.profile)));
    }

    /**
     Overrides the toString() method of the Object class.
     ....
     @return EnrollStudent in the form "First Last mm/dd/yyyy: credits enrolled: creditsEnrolled"
     ...
     */
    @Override
    public String toString(){
        return profile.toString() + ": credits enrolled: " + creditsEnrolled;
    }
}
