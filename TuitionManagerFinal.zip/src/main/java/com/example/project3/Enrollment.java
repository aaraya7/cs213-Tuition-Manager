package com.example.project3;
/**
 Creates an array of enrolled students that can be manipulated and printed.
 @author Aaditya Rayadurgam
 */
public class Enrollment {
    private EnrollStudent[] enrollStudents;
    private int size;
    public static final int RESIZE = 4;
    public static final int NOT_FOUND = -1;

    /**
     Constructor that initializes the instance variables.
     ....
     ...
     */
    public Enrollment(){
        size = RESIZE;
        enrollStudents = new EnrollStudent[size];
    }

    /**
     Getter that returns the enrollStudents instance variable
     ....
     @return enrollStudents array of EnrollStudent objects
     ...
     */
    public EnrollStudent[] getEnrollStudents() {
        return enrollStudents;
    }

    /**
     Adds a specific student to the end of the enrollStudents array.
     ....
     @param enrollStudent is a student of type EnrollStudent
     ...
     */
    public void add(EnrollStudent enrollStudent){
        boolean notAdded = true;
        for(int i = 0; i < size; i++){
            if(enrollStudents[i] == null){
                enrollStudents[i] = enrollStudent;
                notAdded = false;
                break;
            }
        }
        if(notAdded){
            grow();
            add(enrollStudent);
        }
    }

    /**
     Removes a specific student from the array, replacing it with the last student in the array.
     ....
     @param enrollStudent is a student of type EnrollStudent to be removed
     ...
     */
    public void remove(EnrollStudent enrollStudent){
        int removedIndex = find(enrollStudent);
        int numEnrollStudents = numEnrollStudents();
        enrollStudents[removedIndex] = enrollStudents[numEnrollStudents-1];
        enrollStudents[numEnrollStudents-1] = null;
    }

    /**
     Searches the array for a specific enrollStudent.
     ....
     @param enrollStudent is a student of type EnrollStudent to be found
     @return the index of enrollStudent if found, or -1 if not
     ...
     */
    private int find(EnrollStudent enrollStudent){
        for(int i = 0; i < size; i++){
            if(enrollStudents[i].equals(enrollStudent)){
                return i;
            }
        }
        return NOT_FOUND;
    }

    /**
     Returns the index of a specific student in the array.
     @param enrollStudent is a student of type EnrollStudent to be found
     @return the index of the enrollStudent if found, or -1 if not
     */
    public int getIndex(EnrollStudent enrollStudent){
        return find(enrollStudent);
    }
    /**
     Increases the size of the array by 4.
     ....
     ...
     */
    private void grow() {
        EnrollStudent[] temp = enrollStudents;
        size += RESIZE;
        enrollStudents = new EnrollStudent[size];
        for (int i = 0; i < temp.length; i++) {
            enrollStudents[i] = temp[i];
        }
    }

    /**
     Finds the number of students in the array.
     ....
     @return the number of students in the array.
     ...
     */
    public int numEnrollStudents(){
        int numEnrollStudents = 0;
        for(int i = 0; i < size; i++){
            if(enrollStudents[i] != null){
                numEnrollStudents++;
            }
        }
        return numEnrollStudents;
    }

    /**
     Checks if a specific student is in the array.
     ....
     @param enrollStudent is a student of type EnrollStudent to be checked
     @return true if enrollStudent is in the array and false if not
     ...
     */
    public boolean contains(EnrollStudent enrollStudent){
        for(int i = 0; i < numEnrollStudents(); i++){
            if(enrollStudent.equals(enrollStudents[i])){
                return true;
            }
        }
        return false;
    }

    public void changeCredits(EnrollStudent changeTo){
        enrollStudents[find(changeTo)].setCreditsEnrolled(changeTo.getCreditsEnrolled());
    }


    /**
     Prints the array as is without sorting.
     @return enrollment as a String
     */
    public String print(){
        String enrollment = "** Enrollment **\n";
        for(int i = 0; i < numEnrollStudents(); i++) {
            enrollment += enrollStudents[i].toString() + "\n";
        }
        return enrollment + "* end of enrollment *";
    }
}
