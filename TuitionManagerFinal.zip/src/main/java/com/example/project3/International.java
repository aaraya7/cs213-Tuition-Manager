package com.example.project3;
/**
 International subclass of NonResident that creates an international student.
 @author Aaditya Rayadurgam
 */
public class International extends NonResident{
    private boolean isStudyAbroad;
    private static final int INTERNATIONAL_THRESHOLD = 12;

    /**
     Constructor that uses name, date, major, and credit inputs to create objects to initialize the instance variables.
     ....
     @param fname is a first name
     @param lname is a last name
     @param dob is a date in the form "mm/dd/yyyy"
     @param major is a major name
     @param creditCompleted is the number of credits completed by the student
     @param isStudyAbroad is true if the student is in a study abroad program and false otherwise
     ...
     */
    public International(String fname, String lname, String dob, String major, String creditCompleted, String isStudyAbroad){
        super(fname, lname, dob, major, creditCompleted);
        this.isStudyAbroad = Boolean.parseBoolean(isStudyAbroad);
    }

    /**
     Getter that returns whether the International student is in a study abroad program.
     ....
     @return isStudyAbroad instance variable
     ...
     */
    public boolean getStudyAbroad(){
        return isStudyAbroad;
    }

    /**
     Overrides the tuitionDue() method of the NonResident superclass.
     ....
     @param creditsEnrolled is the number of credits the student is enrolled for.
     @return calculated tuition as a double
     ...
     */
    @Override
    public double tuitionDue(int creditsEnrolled){
        double tuition = 0;
        if(creditsEnrolled < PART_TIME_THRESHOLD){
            tuition += (NONRESIDENT_RATE*creditsEnrolled) + (UNIVERSITY_FEE*PART_TIME_FEE);
        }else{
            tuition += (UNIVERSITY_FEE + HEALTH_INSURANCE_FEE);
            if(!isStudyAbroad){
                tuition += NONRESIDENT_TUITION;
            }
            if(creditsEnrolled > CREDIT_THRESHOLD){
                tuition += (NONRESIDENT_RATE*(creditsEnrolled-CREDIT_THRESHOLD));
            }
        }
        return tuition;
    }

    /**
     Overrides the toString() method of the NonResident superclass.
     ....
     @return Student in the form "First Last mm/dd/yyyy (code major school)
     credits completed: credits (standing) (international)"
     ...
     */
    @Override
    public String toString(){
        return super.toString() + " (international)";
    }

    /**
     Overrides the isValid method of the Student superclass.
     ....
     @param creditEnrolled is an int representing the number of credits a student is enrolled for.
     @return whether the number of enrolled credits is between 3 or 12 for study abroad students
     and between 12 and 24 for non-study abroad students.
     ...
     */
    @Override
    public boolean isValid(int creditEnrolled){
        if(isStudyAbroad){
            return creditEnrolled >= MIN_CREDITS && creditEnrolled <= INTERNATIONAL_THRESHOLD;
        }else{
            return creditEnrolled >= INTERNATIONAL_THRESHOLD && creditEnrolled <= MAX_CREDITS;
        }
    }
}
