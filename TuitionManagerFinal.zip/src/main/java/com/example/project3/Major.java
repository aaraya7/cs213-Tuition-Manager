package com.example.project3;
/**
 Defines constants for the majors, their codes, and their schools.
 @author Aaditya Rayadurgam
 */
public enum Major {
    CS ("CS", "SAS", "01:198"),
    MATH ("MATH", "SAS", "01:640"),
    EE ("EE", "SOE","14:332" ),
    ITI ("ITI", "SC&I", "04:547"),
    BAIT ("BAIT", "RBS", "33:136");

    public final String major;
    public final String school;
    public final String code;
    /**
     Constructor that defines the majors, codes, and schools.
     ....
     @param major is a String that represents a major
     @param school is a String that represents a major's school
     @param code is a String that represents a major code
     ...
     */
    private Major(String major, String school, String code){
        this.major = major;
        this.school = school;
        this.code = code;
    }
}