package com.example.project3;
/**
 NonResident subclass of Student that creates a student who is not a resident of New Jersey
 @author Aaditya Rayadurgam
 */
public class NonResident extends Student{
    /**
     Constructor that uses name, date, major, and credit inputs to create objects to initialize the instance variables.
     ....
     @param fname is a first name
     @param lname is a last name
     @param dob is a date in the form "mm/dd/yyyy"
     @param major is a major name
     @param creditCompleted is the number of credits completed by the student
     ...
     */
    public NonResident(String fname, String lname, String dob, String major, String creditCompleted){
        super(fname, lname, dob, major, creditCompleted);
    }

    /**
     Overrides the tuitionDue() method of the Student superclass.
     ....
     @param creditsEnrolled is the number of credits the student is enrolled for.
     @return calculated tuition as a double
     ...
     */
    @Override
    public double tuitionDue(int creditsEnrolled){
        double tuition = 0;
        if(creditsEnrolled < PART_TIME_THRESHOLD){
            tuition += (NONRESIDENT_RATE*creditsEnrolled) + (UNIVERSITY_FEE*PART_TIME_FEE);
        }else{
            tuition += NONRESIDENT_TUITION + UNIVERSITY_FEE;
            if(creditsEnrolled > CREDIT_THRESHOLD){
                tuition += (NONRESIDENT_RATE*(creditsEnrolled-CREDIT_THRESHOLD));
            }
        }
        return tuition;
    }

    /**
     Overrides the isResident() method of the Student superclass.
     ....
     @return false
     ...
     */
    @Override
    public boolean isResident() {
        return false;
    }

    /**
     Overrides the toString() method of the Student superclass.
     ....
     @return Student in the form "First Last mm/dd/yyyy (code major school)
     credits completed: credits (standing) (non-resident)"
     ...
     */
    @Override
    public String toString(){
        return super.toString() + " (non-resident)";
    }
}
