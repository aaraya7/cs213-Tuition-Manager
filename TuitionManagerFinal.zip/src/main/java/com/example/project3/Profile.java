package com.example.project3;
/**
 Takes a name and date of birth and stores them as a Profile object.
 @author Aaditya Rayadurgam
 */
public class Profile implements Comparable<Profile> {
    private String lname;
    private String fname;
    private Date dob;

    /**
     Constructor that uses a name and date to create a Profile object.
     @param fname is a first name
     @param lname is a last name
     @param date is a date in the form "mm/dd/yyyy"
     */
    public Profile(String fname, String lname, String date){
        this.lname = lname;
        this.fname = fname;
        this.dob = new Date(date);
    }

    /**
     Getter that returns the Profile's first name.
     @return fname instance variable
     */
    public String getFname() {
        return fname;
    }

    /**
     Getter that returns the Profile's last name.
     @return lname instance variable
     */
    public String getLname() {
        return lname;
    }

    /**
     Getter that returns the Profile's date of birth.
     @return dob instance variable
     */
    public Date getDob() {
        return dob;
    }

    /**
     Overrides the toString() method of the Object class.
     @return profile in the form "First Last mm/dd/yyyy"
     */
    @Override
    public String toString(){
        return fname + " " + lname + " " + dob.toString();
    }

    /**
     Overrides the equals(Object) method of the Object class.
     @param profile is a profile
     @return true if this profile is equal to the parameter profile and false if not
     */
    @Override
    public boolean equals(Object profile){
        if(!(profile instanceof Profile)){
            return false;
        }
        Profile typed = (Profile) profile;
        return (this.lname.equalsIgnoreCase(typed.lname))&&
                (this.fname.equalsIgnoreCase(typed.fname))&&(this.dob.equals(typed.dob));
    }

    /**
     Overrides the compareTo(T) method of the Comparable interface.
     @param profile is a profile
     @return 1 if this profile is less than the parameter, 0 if equal, and -1 if greater
     */
    @Override
    public int compareTo(Profile profile) {
        if(this.lname.compareTo(profile.lname) > 0){
            return 1;
        }else if (this.lname.compareTo(profile.lname) < 0){
            return -1;
        }else{
            if(this.fname.compareTo(profile.fname) > 0){
                return 1;
            }else if (this.fname.compareTo(profile.fname) < 0){
                return -1;
            }else{
                if(this.dob.compareTo(profile.dob) > 0){
                    return 1;
                } else if (this.dob.compareTo(profile.dob) < 0){
                    return -1;
                }
            }
        }
        return 0;
    }
}