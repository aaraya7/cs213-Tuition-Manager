package com.example.project3;
/**
 Resident subclass of Student that creates a student who is a resident of New Jersey
 @author Aaditya Rayadurgam
 */
public class Resident extends Student{
    private int scholarship;

    /**
     Constructor that uses name, date, major, and credit inputs to create objects to initialize the instance variables.
     ....
     @param fname is a first name
     @param lname is a last name
     @param dob is a date in the form "mm/dd/yyyy"
     @param major is a major name
     @param creditCompleted is the number of credits completed by the student
     ...
     */
    public Resident(String fname, String lname, String dob, String major, String creditCompleted){
        super(fname, lname, dob, major, creditCompleted);
        scholarship = 0;
    }

    /**
     Setter that changes the student's scholarship amount.
     ....
     @param scholarship is the student's scholarship amount.
     ...
     */
    public void setScholarship(int scholarship){
        this.scholarship = scholarship;
    }

    /**
     Overrides the tuitionDue() method of the Student superclass.
     ....
     @param creditsEnrolled is the number of credits the student is enrolled for.
     @return calculated tuition as a double
     ...
     */
    @Override
    public double tuitionDue(int creditsEnrolled) {
        double tuition = 0;
        if(creditsEnrolled < PART_TIME_THRESHOLD){
            tuition += (RESIDENT_RATE*creditsEnrolled) + (UNIVERSITY_FEE*PART_TIME_FEE);
        }else{
            tuition += RESIDENT_TUITION + UNIVERSITY_FEE - scholarship;
            if(creditsEnrolled > CREDIT_THRESHOLD){
                tuition += (RESIDENT_RATE*(creditsEnrolled-CREDIT_THRESHOLD));
            }
        }
        return tuition;
    }

    /**
     Overrides the isResident() method of the Student superclass.
     ....
     @return true
     ...
     */
    @Override
    public boolean isResident(){
        return true;
    }

    /**
     Overrides the toString() method of the Student superclass.
     ....
     @return Student in the form "First Last mm/dd/yyyy (code major school)
     credits completed: credits (standing) (resident)"
     ...
     */
    @Override
    public String toString(){
        return super.toString() + " (resident)";
    }

}
