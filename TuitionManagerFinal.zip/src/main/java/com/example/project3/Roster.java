package com.example.project3;
/**
 Creates a roster of students that can be manipulated and printed.
 @author Aaditya Rayadurgam
 @author Sameer Sharma
 */
public class Roster {
    public static final int NOT_FOUND = -1;
    public static final int RESIZE = 4;
    private Student[] roster;
    private int size;

    /**
     Constructor that initializes the instance variables.
     */
    public Roster(){
        size = RESIZE;
        roster = new Student[size];
    }

    /**
     Getter that returns the roster.
     @return roster array
     */
    public Student[] getRoster() {
        return roster;
    }

    /**
     Searches the roster for a specific student.
     @param student is a student
     @return the index of the student if found, or -1 if not
     */
    private int find(Student student){
        for(int i = 0; i < numStudents(); i++){
            if(roster[i].equals(student)){
                return i;
            }
        }
        return NOT_FOUND;
    }//search the given student in roster

    /**
     Returns the index of a specific student in the roster.
     @param student is a student
     @return the index of the student if found, or -1 if not
     */
    public int getIndex(Student student){
        return find(student);
    }

    /**
     Increases the size of the roster by 4.
     */
    private void grow() {
        Student[] temp = roster;
        size += RESIZE;
        roster = new Student[size];
        for(int i = 0; i < temp.length; i++){
            roster[i] = temp[i];
        }
    }

    /**
     Adds a specific student to the end of the roster.
     @param student is a student
     @return true if the student has been added to the roster and false if not,
     or if the student is already in the roster.
     */
    public boolean add(Student student){
        if(find(student) != -1){
            return false;
        }else{
            for(int i = 0; i < size; i++){
                if(roster[i] == null){
                    roster[i] = student;
                    return true;
                }
            }
            grow();
            add(student);
        }
        return false;
    }//add student to end of array

    /**
     Removes a specific student from the roster while maintaining the order of students.
     @param student is a student
     @return true if the student has been removed from the roster and false if not
     */
    public boolean remove(Student student){
        try{
            int removedIndex = find(student);
            roster[removedIndex] = null;
            int numStudents = numStudents();
            for(int i = removedIndex; i < numStudents; i++){
                roster[i] = roster[i+1];
            }
            roster[numStudents] = null;
            return true;
        }catch(Exception e){
            return false;
        }
    }//maintain the order after remove

    /**
     Checks if a specific student is in the roster.
     @param student is a student
     @return true if the student is in the roster and false if not
     */
    public boolean contains(Student student){
        for(int i = 0; i < numStudents(); i++){
            if(roster[i].equals(student)){
                return true;
            }
        }
        return false;
    } //if the student is in roster

    /**
     Sorts the roster by profile and then prints it.
     @return roster sorted by profile
     */
    public String print(){
        int numStudents = numStudents();
        String sorted = "* Student roster sorted by last name, first name, DOB **\n";
        for(int i = 0; i < numStudents-1; i++){
            if(roster[i] != null){
                for(int j = 0; j < numStudents-1; j++){
                    if(roster[j].compareTo(roster[j+1]) > 0){
                        Student temp = roster[j];
                        roster[j] = roster[j+1];
                        roster[j+1] = temp;
                    }
                }
            }
        }
        for(int k = 0; k < size; k++){
            if(roster[k] != null){
                sorted += roster[k].toString() + "\n";
            }
        }
        return sorted + "* end of roster *";
    } //print roster sorted by profiles

    /**
     Sorts the roster by school and major and then prints it.
     @return roster sorted by school
     */
    public String printBySchoolMajor() {
        int numStudents = numStudents();
        String sorted = "* Student roster sorted by school, major **\n";
        for(int i = 0; i < numStudents-1; i++){
            if(roster[i] != null){
                for(int j = 0; j < numStudents-1; j++){
                    if(roster[j].compareSchoolMajor(roster[j+1]) > 0){
                        Student temp = roster[j];
                        roster[j] = roster[j+1];
                        roster[j+1] = temp;
                    }
                }
            }
        }
        for(int k = 0; k < size; k++){
            if(roster[k] != null){
                sorted += roster[k].toString() + "\n";
            }
        }
        return sorted + "* end of roster *";
    } //print roster sorted by school major

    /**
     Sorts the roster alphabetically by standing and then prints it.
     @return roster sorted by standing
     */
    public String printByStanding() {
        int numStudents = numStudents();
        String sorted = "* Student roster sorted by standing **\n";
        for(int i = 0; i < numStudents-1; i++){
            if(roster[i] != null){
                for(int j = 0; j < numStudents-1; j++){
                    if(roster[j].compareStanding(roster[j+1]) > 0){
                        Student temp = roster[j];
                        roster[j] = roster[j+1];
                        roster[j+1] = temp;
                    }
                }
            }
        }
        for(int k = 0; k < size; k++){
            if(roster[k] != null){
                sorted += roster[k].toString() + "\n";
            }
        }
        return sorted + "* end of roster *";
    } //print roster sorted by standing

    /**
     Finds the number of students in the roster.
     @return the number of students in the roster
     */
    public int numStudents(){
       int numStudents = 0;
       for(int i = 0; i < size; i++){
           if(roster[i] != null){
               numStudents++;
           }
       }
       return numStudents;
    }
}