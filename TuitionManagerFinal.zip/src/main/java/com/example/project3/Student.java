package com.example.project3;
/**
 Takes a profile, major, and number of completed credits and stores them as a Student object.
 @author Aaditya Rayadurgam
 */
public abstract class Student implements Comparable<Student> {
    private Profile profile;
    private Major major; //Major is an enum type
    private int creditCompleted;
    public static final int MIN_CREDITS = 3;
    public static final int MAX_CREDITS = 24;
    public static final int RESIDENT_TUITION = 12536;
    public static final int NONRESIDENT_TUITION = 29737;
    public static final int UNIVERSITY_FEE = 3268;
    public static final int HEALTH_INSURANCE_FEE = 2650;
    public static final int RESIDENT_RATE = 404;
    public static final int NONRESIDENT_RATE = 966;
    public static final double PART_TIME_FEE = .80;
    public static final int PART_TIME_THRESHOLD = 12;
    public static final int CREDIT_THRESHOLD = 16;
    public abstract double tuitionDue(int creditsEnrolled); //polymorphism
    public abstract boolean isResident(); //polymorphism

    public Student(){
        profile = null;
        major = null;
        creditCompleted = 0;
    }

    /**
     Constructor that uses name, date, major, and credit inputs to create objects to initialize the instance variables.
     ....
     @param fname is a first name
     @param lname is a last name
     @param dob is a date in the form "mm/dd/yyyy"
     @param major is a major name
     @param creditCompleted is the number of credits completed by the student
     ...
     */
    public Student(String fname, String lname, String dob, String major, String creditCompleted){
        this.profile = new Profile(fname, lname, dob);//deal with lowercase names. here?
        this.major = Major.valueOf(major.toUpperCase());
        this.creditCompleted = Integer.parseInt(creditCompleted);
    }

    /**
     Getter that returns the Student's number of completed credits.
     @return creditCompleted instance variable
     */
    public int getCreditCompleted() {
        return creditCompleted;
    }

    public void addCredits(int creditCompleted) {
        this.creditCompleted += creditCompleted;
    }

    /**
     Getter that returns the Student's profile.
     @return profile instance variable
     */
    public Profile getProfile() {
        return profile;
    }

    /**
     Getter that returns the Student's major.
     ....
     @return major instance variable
     ...
     */
    public Major getMajor() {
        return major;
    }
    /**
     Setter that changes or sets the Student's major.
     ....
     @param  major to set the instance variable major to
     ...
     */
    public void setMajor(Major major) {
        this.major = major;
    }

    /**
     Overrides the toString() method of the Object class.
     ....
     @return Student in the form "First Last mm/dd/yyyy (code major school) credits completed: credits (standing)"
     ...
     */
    @Override
    public String toString(){
        return profile.toString() + " (" + major.code + " " + major.major + " " + major.school + ") "
                + "credits completed: " + creditCompleted + " (" + standing(creditCompleted) + ")";
    }

    /**
     Helper method to check a student's standing based on their completed credits.
     ....
     @return String value representing the student's standing
     ...
     */
    private String standing(int creditCompleted){
        if(creditCompleted < 30){
            return "Freshman";
        } else if (creditCompleted < 60) {
            return "Sophomore";
        } else if (creditCompleted < 90) {
            return "Junior";
        }else{
            return "Senior";
        }
    }

    /**
     Overrides the equals(Object) method of the Object class.
     ....
     @param student is a student
     @return true if this student's profile is equal to the parameter student's profile and false if not
     ...
     */
    @Override
    public boolean equals(Object student){
        if(!(student instanceof Student)){
            return false;
        }
        Student typed = (Student) student;
        return this.profile.equals(typed.profile);
    }

    /**
     Overrides the compareTo(T) method of the Comparable interface.
     ....
     @param student is a student
     @return 1 if this student's profile is less than the parameter student's profile, 0 if equal, and -1 if greater
     ...
     */
    @Override
    public int compareTo(Student student){
        return this.profile.compareTo(student.profile);
    }

    /**
     Compares two students based on their school and major.
     ....
     @param student is a student
     @return 1 if this student's school and major is less than the parameter student's profile,
     0 if equal, and -1 if greater
     ...
     */
    public int compareSchoolMajor(Student student){
        if(this.major.school.compareTo(student.major.school) != 0){
            return this.major.school.compareTo(student.major.school);
        }else{
            if(this.major.major.compareTo(student.major.major) != 0){
                return this.major.major.compareTo(student.major.major);
            }
        }
        return 0;
    }

    /**
     Compares two students based on their standing.
     ....
     @param student is a student
     @return 1 if this student's standing is alphabetically less than the parameter student's profile,
     0 if equal, and -1 if greater
     ...
     */
    public int compareStanding(Student student){
        if(this.standing(this.creditCompleted).compareTo(student.standing(student.creditCompleted)) != 0){
            return this.standing(this.creditCompleted).compareTo(student.standing(student.creditCompleted));
        }
        return 0;
    }

    /**
     Checks if the student's number of enrolled credits is valid.
     ....
     @param creditEnrolled is an int representing the number of credits a student is enrolled for.
     @return true if the number of enrolled credits is between 3 and 24 and false otherwise.
     ...
     */
    public boolean isValid(int creditEnrolled){
        return creditEnrolled >= MIN_CREDITS && creditEnrolled <= MAX_CREDITS;
    }

    /**
     Testbed method to test the compareTo method of the Student class.
     ....
     @param args is an array containing the command line arguments used as a test input.
     ...
     */
    public static void main(String[] args){
     //   Student testStudent = new Student(args[0], args[1], args[2], args[3], args[4]);
     //   System.out.print(testStudent.toString());
    }


}