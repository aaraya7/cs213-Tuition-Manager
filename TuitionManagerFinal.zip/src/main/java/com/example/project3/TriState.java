package com.example.project3;
/**
 TriState subclass of NonResident that creates a student who is
 not a resident of New Jersey but is from the tri-state area.
 @author Aaditya Rayadurgam
 */
public class TriState extends NonResident{
    private String state;
    private static final int NY_DISCOUNT = 4000;
    private static final int CT_DISCOUNT = 5000;

    /**
     Constructor that uses name, date, major, credit, and state inputs to create objects to initialize the instance variables.
     ....
     @param fname is a first name
     @param lname is a last name
     @param dob is a date in the form "mm/dd/yyyy"
     @param major is a major name
     @param creditCompleted is the number of credits completed by the student
     @param state is the student's home state
     ...
     */
    public TriState(String fname, String lname, String dob, String major, String creditCompleted, String state){
        super(fname, lname, dob, major, creditCompleted);
        this.state = state.toUpperCase();
    }

    /**
     Getter that returns the state of the TriState object.
     ....
     @return state instance variable
     ...
     */
    public String getState() {
        return state;
    }

    /**
     Overrides the tuitionDue() method of the NonResident superclass.
     ....
     @param creditsEnrolled is the number of credits the student is enrolled for.
     @return calculated tuition as a double
     ...
     */
    @Override
    public double tuitionDue(int creditsEnrolled){
        double tuition = 0;
        if(creditsEnrolled < PART_TIME_THRESHOLD){
            tuition += (NONRESIDENT_RATE*creditsEnrolled) + (UNIVERSITY_FEE*PART_TIME_FEE);
        }else{
            tuition += NONRESIDENT_TUITION + UNIVERSITY_FEE;
            if(creditsEnrolled > CREDIT_THRESHOLD){
                tuition += (NONRESIDENT_RATE*(creditsEnrolled-CREDIT_THRESHOLD));
            }
            if(state.equals("NY")){
                tuition -= NY_DISCOUNT;
            }else{
                tuition -= CT_DISCOUNT;
            }
        }
        return tuition;
    }

    /**
     Overrides the toString() method of the NonResident superclass.
     ....
     @return Student in the form "First Last mm/dd/yyyy (code major school)
     credits completed: credits (standing) (tri-state: state)"
     ...
     */
    @Override
    public String toString(){
        return super.toString() + " (tri-state: " + state + ")";
    }

}
