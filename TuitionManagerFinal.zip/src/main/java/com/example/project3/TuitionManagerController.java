package com.example.project3;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.FileChooser;

import java.io.File;
import java.text.DecimalFormat;
import java.util.Scanner;

/**
 Controller class for the Tuition Manager GUI.
 @author Aaditya Rayadurgam
 */
public class TuitionManagerController {
    private static final int MAX_SCHOLARSHIP = 10000;
    private static final int MIN_SCHOLARSHIP = 1;
    private static final int MIN_AGE = 16;
    @FXML
    private RadioButton triState;
    @FXML
    private RadioButton international;
    @FXML
    private RadioButton otherNonResident;
    @FXML
    private RadioButton newYork;
    @FXML
    private RadioButton connecticut;
    @FXML
    private CheckBox studyAbroad;
    @FXML
    private RadioButton sortStanding;
    @FXML
    private RadioButton sortSchool;
    @FXML
    private RadioButton sortProfile;
    @FXML
    private RadioButton printSAS;
    @FXML
    private RadioButton printRBS;
    @FXML
    private RadioButton printSCI;
    @FXML
    private RadioButton printSOE;
    @FXML
    private RadioButton printEnrollment;
    @FXML
    private RadioButton printTuition;
    @FXML
    private Button endSemester;
    @FXML
    private TextArea display;
    @FXML
    private RadioButton rosterPrint;
    @FXML
    private RadioButton schoolPrint;
    @FXML
    private RadioButton enrolledPrint;
    @FXML
    private TextField scholarshipFName;
    @FXML
    private TextField scholarshipLName;
    @FXML
    private DatePicker scholarshipDob;
    @FXML
    private TextField scholarshipAmount;
    @FXML
    private TextField enrollmentFName;
    @FXML
    private TextField enrollmentLName;
    @FXML
    private DatePicker enrollmentDob;
    @FXML
    private TextField enrollmentCredits;
    @FXML
    private TextField rosterFName;
    @FXML
    private TextField rosterLName;
    @FXML
    private DatePicker rosterDob;
    @FXML
    private TextField rosterCredits;
    @FXML
    private RadioButton residentButton;
    @FXML
    private RadioButton rosterCS;
    @FXML
    private RadioButton rosterBAIT;
    @FXML
    private RadioButton rosterITI;
    @FXML
    private RadioButton rosterECE;

    Roster roster;
    Enrollment enrollment;

    /**
     Constructor that initializes the instance variables.
     */
    public TuitionManagerController(){
        roster = new Roster();
        enrollment = new Enrollment();
    }

    /**
     Disables Non-Resident buttons when the Resident button is pressed.
     */
    @FXML
    protected void onResidentButtonPress(){
        triState.setDisable(true);
        international.setDisable(true);
        otherNonResident.setDisable(true);
        newYork.setDisable(true);
        connecticut.setDisable(true);
        studyAbroad.setDisable(true);
    }

    /**
     Enables Non-Resident buttons when the Non-Resident button is pressed.
     */
    @FXML
    protected void onNonResidentButtonPress(){
        triState.setDisable(false);
        international.setDisable(false);
        otherNonResident.setDisable(false);
        newYork.setDisable(false);
        connecticut.setDisable(false);
        studyAbroad.setDisable(false);
    }

    /**
     Enables state buttons and disables the study abroad button when the Tri state button is pressed.
     */
    @FXML
    protected void onTriStateButtonPress(){
        newYork.setDisable(false);
        connecticut.setDisable(false);
        studyAbroad.setDisable(true);
    }

    /**
     Disables state buttons and endables the study abroad button when the International button is pressed.
     */
    @FXML
    protected void onInternationalButtonPress(){
        newYork.setDisable(true);
        connecticut.setDisable(true);
        studyAbroad.setDisable(false);
    }

    /**
     Disables state and study abroad buttons when the Other Non-Resident button is pressed.
     */
    @FXML
    protected void onOtherButtonPress(){
        newYork.setDisable(true);
        connecticut.setDisable(true);
        studyAbroad.setDisable(true);
    }

    /**
     Enables the sort by roster buttons and disables the school
     and enrollment print option buttons when the Roster button is pressed.
     */
    @FXML
    protected void onRosterButtonPress(){
        sortProfile.setDisable(false);
        sortSchool.setDisable(false);
        sortStanding.setDisable(false);
        printSAS.setDisable(true);
        printRBS.setDisable(true);
        printSCI.setDisable(true);
        printSOE.setDisable(true);
        printEnrollment.setDisable(true);
        printTuition.setDisable(true);
    }

    /**
     Disables the sort by roster and enrollment print option buttons and
     enables the school print option buttons when the School button is pressed.
     */
    @FXML
    protected void onSchoolButtonPress(){
        sortProfile.setDisable(true);
        sortSchool.setDisable(true);
        sortStanding.setDisable(true);
        printSAS.setDisable(false);
        printRBS.setDisable(false);
        printSCI.setDisable(false);
        printSOE.setDisable(false);
        printEnrollment.setDisable(true);
        printTuition.setDisable(true);
    }

    /**
     Disables the sort by roster and school print option buttons and
     enables the enrollment print option buttons when the Enrollment button is pressed.
     */
    @FXML
    protected void onEnrollmentButtonPress(){
        sortProfile.setDisable(true);
        sortSchool.setDisable(true);
        sortStanding.setDisable(true);
        printSAS.setDisable(true);
        printRBS.setDisable(true);
        printSCI.setDisable(true);
        printSOE.setDisable(true);
        printEnrollment.setDisable(false);
        printTuition.setDisable(false);
    }

    /**
     Ends the semester when the endSemester button is pressed, adding enrolled credits to
     completed credits for all enrolled students and then printing all students in the roster eligible to graduate.
     */
    @FXML
    protected void onEndSemesterButtonPress(){
        if(rosterNotEmpty()){
            for(int j = 0; j < enrollment.numEnrollStudents(); j++){
                EnrollStudent enrolled = enrollment.getEnrollStudents()[j];
                roster.getRoster()[roster.getIndex(new Resident(enrolled.getProfile().getFname(),
                        enrolled.getProfile().getLname(), enrolled.getProfile().getDob().toString(),
                        "CS", "0"))].addCredits(enrolled.getCreditsEnrolled());
            }
            String endsem = "";
            for(int i = 0; i < roster.numStudents(); i++){
                if(roster.getRoster()[i].getCreditCompleted() >= 120){
                    endsem += roster.getRoster()[i].toString() + "\n";
                }
            }
            if(endsem.equals("")){
                display.setText("No Students Eligible for Graduation!");
            }else{
                display.setText("* Students Eligible for Graduation *\n" + endsem + "* End of List **");
            }
        }else{
            display.setText("Student Roster is Empty!");
        }
        endSemester.setDisable(true);
    }

    /**
     Prints a list of students when the Print button is pressed, based on the options chosen in the Print tab.
     */
    @FXML
    protected void onPrintButtonPress(){
        if(rosterPrint.isSelected()){
            if(rosterNotEmpty()){
                if(sortProfile.isSelected()){
                    display.setText(roster.print());
                }else if(sortSchool.isSelected()){
                    display.setText(roster.printBySchoolMajor());
                }else if(sortStanding.isSelected()){
                    display.setText(roster.printByStanding());
                }
            }else{
                display.setText("Student Roster is Empty!");
            }
        }else if(schoolPrint.isSelected()){
            if(printSAS.isSelected()){
                display.setText(list("SAS"));
            }else if(printRBS.isSelected()){
                display.setText(list("RBS"));
            }else if(printSOE.isSelected()){
                display.setText(list("SOE"));
            }else if(printSCI.isSelected()){
                display.setText(list("SC&I"));
            }
        }else if(enrolledPrint.isSelected()){
            if(enrollmentNotEmpty()){
                if(printEnrollment.isSelected()){
                    display.setText(enrollment.print());
                }else if(printTuition.isSelected()){
                    display.setText(printTuition());
                }
            }else{
                display.setText("No Students Enrolled!");
            }
        }
    }
    /**
     Compiles all the students in a single school into a list
     @param school is the name of the school
     @return all the students in a school
     */
    private String list(String school){
        String list = "* Students in " + school + " *\n";
        for(int i = 0; i < roster.numStudents(); i++){
            if(roster.getRoster()[i].getMajor().school.equals(school)){
                list += roster.getRoster()[i].toString() + "\n";
            }
        }

        if(rosterNotEmpty()){
            if(list.equals("* Students in " + school + " *\n")){
                return school + " is Empty!";
            }
        }else{
            return "Student Roster is Empty!";
        }

        return list + "* End of List **";
    }

    /**
     Compiles all the enrolled students and their tuition dues into a list
     @return a list of all enrolled students and their tuition dues
     */
    private String printTuition(){
        if(rosterNotEmpty()){
            String tuitionDue = "** Tuition Due **\n";
            for (int i = 0; i < enrollment.numEnrollStudents(); i++) {
                EnrollStudent enrolled = enrollment.getEnrollStudents()[i];
                Student inRoster = roster.getRoster()[roster.getIndex(new Resident(enrolled.getProfile().getFname(),
                        enrolled.getProfile().getLname(), enrolled.getProfile().getDob().toString(),
                        "CS", "0"))];
                int creditsEnrolled = enrolled.getCreditsEnrolled();
                DecimalFormat df = new DecimalFormat("##,###.00");
                String tuition = df.format(inRoster.tuitionDue(creditsEnrolled));
                if (inRoster instanceof Resident student) {
                    tuitionDue += student.getProfile().toString() + " (Resident) Enrolled "
                            + enrolled.getCreditsEnrolled() + " Credits: Tuition Due: $" + tuition + "\n";
                }else if (inRoster instanceof TriState student) {
                    tuitionDue += student.getProfile().toString() + " (Tri-State "+ student.getState() + ") " +
                            "Enrolled " + enrolled.getCreditsEnrolled() + " Credits: Tuition Due: $" + tuition + "\n";
                } else if (inRoster instanceof International student) {
                    String studyAbroad = "";
                    if(student.getStudyAbroad()){
                        studyAbroad = "Study Abroad";
                    }
                    tuitionDue += student.getProfile().toString() + " (International Student - " + studyAbroad + ") " +
                            " Enrolled " + enrolled.getCreditsEnrolled() + " Credits: Tuition Due: $" + tuition + "\n";
                } else if (inRoster instanceof NonResident student) {
                    tuitionDue += student.getProfile().toString() + " (Non-Resident) Enrolled "
                            + enrolled.getCreditsEnrolled() + " Credits: Tuition Due: $" + tuition + "\n";
                }
            }
            return tuitionDue + "* End of Tuition Due *";
        }else{
            return "Student Roster is Empty!";
        }
    }

    /**
     Updates an enrolled student's scholarship amount when the Scholarship button is pressed.
     */
    @FXML
    protected void onScholarshipButtonPress(){
        if(fieldsEmpty(scholarshipFName, scholarshipLName, scholarshipDob, scholarshipAmount)){
            display.setText("Error: Missing Data!");
        }else if(!rosterNotEmpty()){
            display.setText("Student Roster is Empty!");
        }else if(!enrollmentNotEmpty()){
            display.setText("No Students Enrolled!");
        }else{
            display.setText(checkAmount());
        }
    }
    /**
     Updates a student's scholarship and checks for errors.
     @return an error message or a confirmation of scholarship update.
     */
    protected String checkAmount(){
        Student temp = new Resident(scholarshipFName.getText(), scholarshipLName.getText(),
                dateToString(scholarshipDob), "CS", "0");
        EnrollStudent inEnrollment = new EnrollStudent(scholarshipFName.getText(), scholarshipLName.getText(),
                dateToString(scholarshipDob), "0");
        if(!roster.contains(temp)){
            return temp.getProfile().toString() + " Not in Roster!";
        }else if(!enrollment.contains(inEnrollment)){
            return temp.getProfile().toString() + " is Not Enrolled!";
        }else if(!roster.getRoster()[roster.getIndex(temp)].isResident()){
            return temp.getProfile().toString() + " (Non-Resident) is Ineligible for a Scholarship!";
        }else if(enrollment.getEnrollStudents()[enrollment.getIndex(inEnrollment)].getCreditsEnrolled()
                < Student.PART_TIME_THRESHOLD){
            return temp.getProfile().toString() + " (Part Time Student) is Ineligible for a Scholarship!";
        }else{
            try{
                int scholarship = Integer.parseInt(scholarshipAmount.getText());
                if(scholarship < MIN_SCHOLARSHIP || scholarship > MAX_SCHOLARSHIP){
                    return "Amount Invalid: " + scholarship + "!";
                }
            }catch(Exception e){
                return "Amount is Not an Integer!";
            }
        }
        ((Resident) roster.getRoster()[roster.getIndex(temp)]).setScholarship(
                Integer.parseInt(scholarshipAmount.getText()));
        return "Scholarship Amount Updated!";
    }

    /**
     Enrolls a student when the enrollment button is pressed.
     */
    @FXML
    protected void onEnrollButtonPress(){
        if(fieldsEmpty(enrollmentFName, enrollmentLName, enrollmentDob, enrollmentCredits)){
            display.setText("Error: Missing Data!");
        }else if(!rosterNotEmpty()){
            display.setText("Student Roster is Empty!");
        }else{
            display.setText(checkEnroll());
        }
    }

    /**
     Adds a student to enrollment and checks for errors.
     @return either an error message or confirmation of enrollment.
     */
    protected String checkEnroll(){
        try{
            EnrollStudent toEnroll = new EnrollStudent(enrollmentFName.getText(), enrollmentLName.getText(),
                    dateToString(enrollmentDob), enrollmentCredits.getText());
            Student temp = new Resident(enrollmentFName.getText(), enrollmentLName.getText(),
                    dateToString(enrollmentDob), "CS" , "0");
            if(!roster.contains(temp)){
                return temp.getProfile() + " Not in Roster!";
            }else if(enrollment.contains(toEnroll) && enrollment.getEnrollStudents()
                    [enrollment.getIndex(toEnroll)].getCreditsEnrolled() == toEnroll.getCreditsEnrolled()){
                return temp.getProfile() + " Already Enrolled!";
            }else if(!temp.isValid(Integer.parseInt(enrollmentCredits.getText()))){
                Student inRoster = roster.getRoster()[roster.getIndex(temp)];
                if(inRoster instanceof Resident){
                    return "(Resident): Invalid Credit Hours!";
                }else if(inRoster instanceof TriState){
                    return "(Tri-State): Invalid Credit Hours!";
                }else if(inRoster instanceof International){
                    if(((International) inRoster).getStudyAbroad()){
                        return "(International Student - Study Abroad): Invalid Credit Hours!";
                    }
                    return "(International Student): Invalid Credit Hours!";
                }else if(inRoster instanceof NonResident){
                    return "(Non-Resident): Invalid Credit Hours!";
                }
            }
            if(enrollment.contains(toEnroll)){
                enrollment.changeCredits(toEnroll);
            }else{
                enrollment.add(toEnroll);
            }
            return temp.getProfile() + " Enrolled " + enrollmentCredits.getText() + " Credits!";
        }catch(Exception e){
            return "Number of Credit Hours is Not an Integer!";
        }
    }

    /**
     Drops a student from enrollment when the drop button is pressed, and handles errors.
     */
    @FXML
    protected void onDropButtonPress(){
        if(fieldsEmpty(enrollmentFName, enrollmentLName, enrollmentDob, new TextField("Filler"))){
            display.setText("Error: Missing Data!");
        }else if(!rosterNotEmpty()){
            display.setText("Student Roster is Empty!");
        }else if(!enrollmentNotEmpty()){
            display.setText("No Students Enrolled!");
        }else{
            EnrollStudent drop = new EnrollStudent(enrollmentFName.getText(), enrollmentLName.getText(),
                    dateToString(enrollmentDob), "0");
            if(enrollment.contains(drop)){
                enrollment.remove(drop);
                display.setText(enrollmentFName.getText() + " " + enrollmentLName.getText() + " " +
                        dateToString(enrollmentDob) + " Dropped!");
            }else{
                display.setText(enrollmentFName.getText() + " " + enrollmentLName.getText() + " " +
                        dateToString(enrollmentDob) + " is Not Enrolled!");
            }
        }
    }

    /**
     Loads a file of students when the load button is pressed.
     */
    @FXML
    protected void onLoadButtonPress(){
        FileChooser fileChooser = new FileChooser();
        File file = fileChooser.showOpenDialog(null);
        try{
            Scanner readFile = new Scanner(file);
            while(readFile.hasNextLine()){
                String[] line = readFile.nextLine().split(",");
                roster.add(makeLoadStudent(line));
            }
            display.setText("Students Loaded to Roster!");
        }catch(Exception e){
            display.setText("Error: File Cannot Be Read!");
        }
    }

    /**
     Makes a student from a line of file input.
     @return student created from a line of file input
     */
    protected Student makeLoadStudent(String[] operation){
        if(operation[0].equals("R")){
            return new Resident(operation[1], operation[2], operation[3], operation[4], operation[5]);
        }else if(operation[0].equals("N")){
            return new NonResident(operation[1], operation[2], operation[3], operation[4], operation[5]);
        }else if(operation[0].equals("T")){
            return new TriState(operation[1], operation[2], operation[3],
                    operation[4], operation[5], operation[6]);
        }else if(operation.length == 7){
            return new International(operation[1], operation[2], operation[3],
                    operation[4], operation[5], operation[6]);
        }else{
            return new International(operation[1], operation[2], operation[3],
                    operation[4], operation[5], "false");
        }
    }

    /**
     Changes a student's major when the change major button is pressed, and handles errors.
     */
    @FXML
    protected void onChangeButtonPress(){
        if(fieldsEmpty(rosterFName, rosterLName, rosterDob, new TextField("Filler"))){
            display.setText("Error: Missing Data!");
        }else if(!rosterNotEmpty()){
            display.setText("Student Roster is Empty!");
        }else{
            String major = selectedMajor();
            Student change = new Resident(rosterFName.getText(), rosterLName.getText(), dateToString(rosterDob),
                    major, "0");
            if(roster.contains(change)){
                if(roster.getRoster()[roster.getIndex(change)].compareSchoolMajor(change) == 0){
                    display.setText(change.getProfile().toString() + " Major Is Already " + major + "!");
                }else{
                    roster.getRoster()[roster.getIndex(change)].setMajor(Major.valueOf(major));
                    display.setText(change.getProfile().toString() + " Major Changed to " + major + "!");
                }
            }else{
                display.setText(change.getProfile().toString() + " is Not in the Roster!");
            }
        }
    }

    /**
     Adds a student to the roster when the add button is pressed, and handles errors.
     */
    @FXML
    protected void onAddButtonPress(){
        if(fieldsEmpty(rosterFName, rosterLName, rosterDob, rosterCredits)){
            display.setText("Error: Missing Data!");
        }else{
            try{
                Student toAdd = makeStudent();
                if(toAdd.getProfile().getDob().age() < MIN_AGE){
                    display.setText("DOB Invalid: Younger Than 16 Years Old!");
                }else if(roster.contains(toAdd)){
                    display.setText(toAdd.getProfile().toString() + " is Already in the Roster!");
                }else if(toAdd.getCreditCompleted() < 0){
                    display.setText("Number of Credits Completed is Negative!");
                }else{
                    roster.add(toAdd);
                    display.setText(toAdd.getProfile().toString() + " Added to the Roster!");
                }
            }catch(Exception e){
                display.setText("Number of Credits Completed is Not An Integer!");
            }
        }
    }

    /**
     Removes a student from the roster when the remove button is pressed, and handles errors.
     */
    @FXML
    protected void onRemoveButtonPress(){
        if(fieldsEmpty(rosterFName, rosterLName, rosterDob, new TextField("Filler"))){
            display.setText("Error: Missing Data!");
        }else if(!rosterNotEmpty()){
            display.setText("Student Roster is Empty!");
        }else{
            Student toRemove = new Resident(rosterFName.getText(), rosterLName.getText(), dateToString(rosterDob),
                    "CS", "0");
            EnrollStudent check = new EnrollStudent(rosterFName.getText(), rosterLName.getText(),
                    dateToString(rosterDob), "0");
            if(roster.contains(toRemove)){
                if(enrollment.contains(check)){
                    display.setText(toRemove.getProfile().toString() + " is Enrolled and Cannot Be Removed!");
                }else{
                    roster.remove(toRemove);
                    display.setText(toRemove.getProfile().toString() + " Removed From the Roster!");
                }
            }else{
                display.setText(toRemove.getProfile().toString() + " is Not in the Roster!");
            }
        }
    }

    /**
     Makes a student from user input in the roster tab.
     @return student created from user input in the roster tab
     */
    protected Student makeStudent(){
        if(residentButton.isSelected()){
            return new Resident(rosterFName.getText(), rosterLName.getText(), dateToString(rosterDob),
                    selectedMajor(), rosterCredits.getText());
        }else{
            if(triState.isSelected()){
                if(newYork.isSelected()){
                    return new TriState(rosterFName.getText(), rosterLName.getText(), dateToString(rosterDob),
                            selectedMajor(), rosterCredits.getText(), "NY");
                }else{
                    return new TriState(rosterFName.getText(), rosterLName.getText(), dateToString(rosterDob),
                            selectedMajor(), rosterCredits.getText(), "CT");
                }
            }else if(international.isSelected()){
                if(studyAbroad.isSelected()){
                    return new International(rosterFName.getText(), rosterLName.getText(), dateToString(rosterDob),
                            selectedMajor(), rosterCredits.getText(), "true");
                }else{
                    return new International(rosterFName.getText(), rosterLName.getText(), dateToString(rosterDob),
                            selectedMajor(), rosterCredits.getText(), "false");
                }
            }else{
                return new NonResident(rosterFName.getText(), rosterLName.getText(), dateToString(rosterDob),
                        selectedMajor(), rosterCredits.getText());
            }
        }
    }

    /**
     Checks which of the major buttons is selected.
     @return the name of the selected major
     */
    protected String selectedMajor(){
        if(rosterCS.isSelected()){
            return "CS";
        }else if(rosterBAIT.isSelected()){
            return "BAIT";
        }else if(rosterITI.isSelected()){
            return "ITI";
        }else if(rosterECE.isSelected()){
            return "ECE";
        }else{
            return "MATH";
        }
    }

    /**
     Converts a DatePicker object to a String.
     @return date in the form mm/dd/yyyy
     */
    protected String dateToString(DatePicker date){
        return date.getValue().getMonthValue() + "/" + date.getValue().getDayOfMonth()
                + "/" + date.getValue().getYear();
    }

    /**
     Checks if any user entry fields were left blank.
     @return true if any fields are blank and false otherwise
     */
    protected boolean fieldsEmpty(TextField fname, TextField lname, DatePicker dob, TextField num){
        return fname.getText().equals("") || lname.getText().equals("") || dob == null || num.getText().equals("");
    }

    /**
     Checks if the roster contains students.
     @return false if empty and true otherwise
     */
    protected boolean rosterNotEmpty(){
        return roster.numStudents() != 0;
    }

    /**
     Checks if enrollment contains students.
     @return false if empty and true otherwise
     */
    protected boolean enrollmentNotEmpty(){
        return enrollment.numEnrollStudents() != 0;
    }
}