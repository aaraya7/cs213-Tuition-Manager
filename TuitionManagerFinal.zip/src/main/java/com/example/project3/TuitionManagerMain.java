package com.example.project3;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

/**
 Main class that creates the stage and launches the GUI.
 @author Aaditya Rayadurgam
 */
public class TuitionManagerMain extends Application {

    /**
     Checks if enrollment contains students.
     @param stage is the stage on which the GUI is built.
     */
    @Override
    public void start(Stage stage) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(TuitionManagerMain.class.getResource("TuitionManagerView.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 500, 600);
        stage.setTitle("Project 3 - Tuition Manager");
        stage.setScene(scene);
        stage.show();
    }

    /**
     Main method to launch the GUI.
     @param args is an array of arguments
     */
    public static void main(String[] args) {
        launch();
    }
}